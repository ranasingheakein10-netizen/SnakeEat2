const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const levelDisplay = document.getElementById("level");
const highScoreDisplay = document.getElementById("highScore");
const currentScoreDisplay = document.getElementById("currentScore");
const pauseMessage = document.getElementById("pauseMessage");

const box = 20; // Size of each square block for the snake and food
let snake = [{ x: 9 * box, y: 9 * box }];
let food = { x: Math.floor(Math.random() * 25) * box, y: Math.floor(Math.random() * 25) * box };
let score = 0;
let level = 1;
let direction;
let paused = false;
let highScore = 0;

const levelScores = [8, 12, 16, 20, 25]; // Scores needed to donate for each level
const gameSpeeds = [200, 180, 160, 140, 120]; // Speed decreases as levels increase

// Store the key mappings for the snake movement
const directions = {
  37: "left",
  38: "up",
  39: "right",
  40: "down"
};

let gameSpeed = gameSpeeds[0]; // Default speed at level 1

function draw() {
  if (paused) return; // Pause the game if the game is paused

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw snake
  snake.forEach((segment, index) => {
    ctx.fillStyle = index === 0 ? "yellow" : "green"; // Yellow for head, green for body
    ctx.fillRect(segment.x, segment.y, box, box);
  });

  // Draw food
  ctx.fillStyle = "red";
  ctx.fillRect(food.x, food.y, box, box);

  // Draw score and level
  levelDisplay.textContent = `Level: ${level}`;
  highScoreDisplay.textContent = `High Score: ${highScore}`;
  currentScoreDisplay.textContent = `Current Score: ${score}`;

  moveSnake();
  checkCollisions();

  // Adjust game speed based on level
  setTimeout(draw, gameSpeed); // Dynamic speed based on the level
}

function moveSnake() {
  let head = { ...snake[0] };

  // Move the snake based on the current direction
  if (direction === "left") head.x -= box;
  if (direction === "right") head.x += box;
  if (direction === "up") head.y -= box;
  if (direction === "down") head.y += box;

  // Handle the snake wrapping around when it hits the walls
  if (head.x < 0) head.x = canvas.width - box; // Snake wraps to the right
  if (head.x >= canvas.width) head.x = 0; // Snake wraps to the left
  if (head.y < 0) head.y = canvas.height - box; // Snake wraps to the bottom
  if (head.y >= canvas.height) head.y = 0; // Snake wraps to the top

  // Check if the snake eats the food
  if (head.x === food.x && head.y === food.y) {
    score++;
    food = { x: Math.floor(Math.random() * 25) * box, y: Math.floor(Math.random() * 25) * box };

    // Check if the player has earned enough points to level up
    if (score >= levelScores[level - 1]) {
      levelUp();
    }
  } else {
    snake.pop(); // Remove the last part of the snake body to make it move
  }

  // Add the new head to the snake
  snake.unshift(head);
}

function checkCollisions() {
  let head = snake[0];

  // Check if the snake collides with itself
  for (let i = 1; i < snake.length; i++) {
    if (head.x === snake[i].x && head.y === snake[i].y) {
      endGame();
    }
  }
}

function levelUp() {
  level++; // Increase level
  if (level > 5) {
    level = 5; // Limit to level 5
  }
  
  // Update speed for the next level
  gameSpeed = gameSpeeds[level - 1];
  score = 0; // Reset score after leveling up
}

function endGame() {
  if (score > highScore) {
    highScore = score;
  }
  score = 0;
  level = 1;
  snake = [{ x: 9 * box, y: 9 * box }];
  gameSpeed = gameSpeeds[0]; // Reset speed to level 1 on game over
  alert("Game Over!");
}

function keyDown(event) {
  if (event.keyCode === 32) { // Spacebar to pause/unpause
    paused = !paused;
    if (paused) {
      pauseMessage.textContent = "Game paused. Press Space to resume.";
    } else {
      pauseMessage.textContent = "";
      draw(); // Resume the game if it's unpaused
    }
    return;
  }
  
  // Prevent Enter from being used during gameplay
  if (event.keyCode === 13 && !paused) { 
    return; // Do nothing if Enter is pressed during the game
  }
  
  if (paused) return; // Don't allow movement when paused
  if (directions[event.keyCode]) direction = directions[event.keyCode];
}

function startGame() {
  score = 0;
  level = 1;
  snake = [{ x: 9 * box, y: 9 * box }];
  direction = "right"; // Start moving the snake right initially
  paused = false;
  gameSpeed = gameSpeeds[0]; // Set initial speed (level 1 speed)
  pauseMessage.textContent = ""; // Clear pause message
  document.addEventListener("keydown", keyDown);
  draw(); // Start the game loop
}

document.addEventListener("keydown", (event) => {
  if (event.keyCode === 13 && !paused) { // Enter to start the game (if not paused)
    startGame();
  } else if (event.keyCode === 13 && paused) {
    return; // Don't do anything if Enter is pressed during gameplay
  }
});
